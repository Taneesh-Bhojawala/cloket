import React, { useState } from "react";
import {
  TextField,
  Button,
  Typography,
  Paper,
  Box,
  MenuItem,
  Autocomplete,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import { State, City } from "country-state-city";
import { useSelector } from "react-redux";

export default function AddressPage() {
  const navigate = useNavigate();
  const currentUser = useSelector((state) => state.user);

  const [form, setForm] = useState({
    line1: "",
    line2: "",
    pincode: "",
    stateCode: "",
    stateName: "",
    city: "",
    tag: "",
  });

  const [errors, setErrors] = useState({});
  const [cityOptions, setCityOptions] = useState([]);

  const handleChange = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    setErrors((prev) => ({ ...prev, [field]: false }));
  };

  const validate = () => {
    const newErrors = {
      line1: !form.line1.trim(),
      pincode: !form.pincode.trim(),
      stateCode: !form.stateCode,
      city: !form.city,
      tag: !form.tag,
    };
    setErrors(newErrors);
    return !Object.values(newErrors).some(Boolean);
  };

  const handleSave = () => {
    if (!validate()) return;

    const users = JSON.parse(localStorage.getItem("users")) || [];

    const updatedUsers = users.map((u) => {
      if (u.email === currentUser.email) {
        const newAddress = {
          id: crypto.randomUUID(),
          ...form,
          state: form.stateName, // store readable name
        };

        return {
          ...u,
          addressBook: [...(u.addressBook || []), newAddress],
        };
      }
      return u;
    });

    localStorage.setItem("users", JSON.stringify(updatedUsers));
    alert("Address saved!");
    navigate("/cart");
  };

  return (
    <Box sx={{ display: "flex", justifyContent: "center", mt: 4 }}>
      <Paper sx={{ p: 4, width: 400 }}>
        <Typography variant="h5" gutterBottom>
          Add Delivery Address 📦
        </Typography>

        <TextField
          label="Address Line 1"
          fullWidth
          required
          value={form.line1}
          error={errors.line1}
          helperText={errors.line1 ? "Address Line 1 is required" : ""}
          onChange={(e) => handleChange("line1", e.target.value)}
          sx={{ mb: 2 }}
        />

        <TextField
          label="Address Line 2"
          fullWidth
          value={form.line2}
          onChange={(e) => handleChange("line2", e.target.value)}
          sx={{ mb: 2 }}
        />

        <TextField
          label="Pincode"
          type="text"
          fullWidth
          required
          value={form.pincode}
          onChange={(e) => {
            const val = e.target.value;
            if (/^\d*$/.test(val) && val.length <= 6) {
              handleChange("pincode", val);
            }
          }}
          sx={{ mb: 2 }}
        />

        {/* STATE DROPDOWN */}
        <TextField
          select
          fullWidth
          label="State"
          value={form.stateCode}
          onChange={(e) => {
            const selectedState = State.getStatesOfCountry("IN").find(
              (s) => s.isoCode === e.target.value
            );
            setForm((prev) => ({
              ...prev,
              stateCode: selectedState.isoCode,
              stateName: selectedState.name,
              city: "",
            }));
            setCityOptions(City.getCitiesOfState("IN", selectedState.isoCode));
          }}
          required
          sx={{ mb: 2 }}
        >
          {State.getStatesOfCountry("IN").map((s) => (
            <MenuItem key={s.isoCode} value={s.isoCode}>
              {s.name}
            </MenuItem>
          ))}
        </TextField>

        {/* CITY AUTOCOMPLETE */}
        <Autocomplete
          options={cityOptions.map((c) => c.name)}
          value={form.city}
          onChange={(_, v) => handleChange("city", v)}
          renderInput={(params) => (
            <TextField
              {...params}
              label="City"
              fullWidth
              required
              error={errors.city}
              helperText={errors.city ? "City is required" : ""}
              sx={{ mb: 2 }}
            />
          )}
        />

        {/* TAG SELECT */}
        <TextField
          select
          label="Address Type"
          fullWidth
          required
          value={form.tag}
          error={errors.tag}
          helperText={errors.tag ? "Please select address type" : ""}
          onChange={(e) => handleChange("tag", e.target.value)}
          sx={{ mb: 2 }}
        >
          <MenuItem value="Home">Home</MenuItem>
          <MenuItem value="Work">Work</MenuItem>
          <MenuItem value="Other">Other</MenuItem>
        </TextField>

        <Button variant="contained" fullWidth onClick={handleSave}>
          Save Address
        </Button>
      </Paper>
    </Box>
  );
}
