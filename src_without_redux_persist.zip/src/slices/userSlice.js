import { createSlice } from "@reduxjs/toolkit";
const initialUser = JSON.parse(localStorage.getItem("currentUser"));
const userSlice = createSlice(
    {
        name: "user",
        initialState: initialUser || null,
        reducers:
        {
            login: (state, action) =>
            {
                localStorage.setItem("currentUser", JSON.stringify(action.payload));
                return action.payload;
            },

            logout: () =>
            {
                localStorage.removeItem("currentUser");
                return null;
            },
        },
    }
);

export const {login, logout} = userSlice.actions;
export default userSlice.reducer;