import { createSlice } from "@reduxjs/toolkit";

const getSavedCart = (user) => {
  if (!user) {
    return [];
  }
  const saved = localStorage.getItem(`cart_${user}`);
  return saved ? JSON.parse(saved) : [];
};

const initialState = {
  items: [],
  user: null,
};

const cartSlice = createSlice({
  name: "cart",
  initialState,
  reducers: {
    setCartUser: (state, action) => {
      state.user = action.payload;
      state.items = getSavedCart(state.user);
    },

    addToCart: (state, action) => {
      const alreadyExist = state.items.some((item) => item.id === action.payload.id);
      if (!alreadyExist) {
        state.items.push(action.payload);
        localStorage.setItem(`cart_${state.user}`, JSON.stringify(state.items));
      }
    },

    removeFromCart: (state, action) => {
      state.items = state.items.filter((item) => item.id !== action.payload);
      localStorage.setItem(`cart_${state.user}`, JSON.stringify(state.items));
    },

    clearCart: (state) => {
      state.items = [];
    },
  },
});

export const { addToCart, removeFromCart, clearCart, setCartUser } = cartSlice.actions;
export default cartSlice.reducer;
