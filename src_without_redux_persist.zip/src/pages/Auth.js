import React, { useState } from "react";
// import { useUser } from "../context/UserContext";
import {
  TextField,
  Button,
  Typography,
  Box,
  Paper,
} from "@mui/material";
import { useNavigate } from "react-router-dom";

// Redux
import { useDispatch } from "react-redux";
import { login } from "../slices/userSlice";
import { setCartUser } from "../slices/cartSlice";

export default function Auth() {
  // const { login } = useUser(); // old context
  const dispatch = useDispatch(); // Redux dispatch

  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleSubmit = () => {
    if (!username || !password) {
      alert("Username and password are required.");
      return;
    }

    const users = JSON.parse(localStorage.getItem("users") || "[]");

    if (isLogin) {
      const user = users.find(
        (u) => u.username === username && u.password === password
      );

      if (user) {
        dispatch(login(username));        // Set current user in store
        dispatch(setCartUser(username));  // Load their cart
        alert("Login successful!");
        navigate("/");
      } else {
        alert("Invalid username or password.");
      }
    } else {
      const userExists = users.some((u) => u.username === username);

      if (userExists) {
        alert("Username already taken.");
        return;
      }

      const newUser = { username, password };
      const updatedUsers = [...users, newUser];

      localStorage.setItem("users", JSON.stringify(updatedUsers));
      dispatch(login(username));
      dispatch(setCartUser(username));
      alert("Registered successfully!");
      navigate("/");
    }
  };

  return (
    <Box sx={{ display: "flex", justifyContent: "center", mt: 8 }}>
      <Paper sx={{ p: 4, width: 320, textAlign: "center" }}>
        <Typography variant="h5" gutterBottom>
          {isLogin ? "Login" : "Register"}
        </Typography>

        <TextField
          fullWidth
          label="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          sx={{ mb: 2 }}
        />

        <TextField
          fullWidth
          label="Password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          sx={{ mb: 2 }}
        />

        <Button fullWidth variant="contained" onClick={handleSubmit}>
          {isLogin ? "Login" : "Register"}
        </Button>

        <Button
          fullWidth
          sx={{ mt: 1 }}
          onClick={() => setIsLogin((prev) => !prev)}
        >
          {isLogin ? "Register?" : "Login?"}
        </Button>
      </Paper>
    </Box>
  );
}
