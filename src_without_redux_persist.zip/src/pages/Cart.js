import React from "react";
import { useNavigate } from "react-router-dom";
// import { useCart } from "../context/CartContext";
// import { useUser } from "../context/UserContext";
import { useSelector, useDispatch } from "react-redux";
import { removeFromCart, clearCart } from "../slices/cartSlice";
import { Container, Typography, Grid, Button, Box } from "@mui/material";
import ProductCard from "../components/ProductCard";

export default function Cart() {
  // const { cartItems, removeFromCart, clearCart } = useCart();
  // const { user } = useUser();

  const navigate = useNavigate();
  const dispatch = useDispatch();

  const user = useSelector((state) => state.user);
  const cartItems = useSelector((state) => state.cart.items || []);

  if (!user) {
    return (
      <>
        <Typography variant="h5" align="center" sx={{ mt: 8 }}>
          Login to view your cart
        </Typography>

        <Box sx={{ display: "flex", justifyContent: "center", mt: 2 }}>
          <Button variant="contained" onClick={() => navigate("/login")}>
            Login
          </Button>
        </Box>
      </>
    );
  }

  if (cartItems.length === 0) {
    return (
      <Typography variant="h5" align="center" sx={{ mt: 8 }}>
        Your Cart is Empty 🛒
      </Typography>
    );
  }

  return (
    <Container sx={{ mt: 4, mb: 5 }}>
      <Typography variant="h4" gutterBottom>
        Your Cart 🛒
      </Typography>
      <Button
        sx={{ my: 2, backgroundColor: "red", color: "black" }}
        onClick={() => dispatch(clearCart())}
      >
        Clear Cart
      </Button>
      <Grid container spacing={3}>
        {cartItems.map((product) => (
          <Grid item xs={12} sm={6} md={3} key={product.id}>
            <ProductCard
              product={product}
              showRemoveButton
              onRemove={(id) => dispatch(removeFromCart(id))}
            />
          </Grid>
        ))}
      </Grid>
    </Container>
  );
}
